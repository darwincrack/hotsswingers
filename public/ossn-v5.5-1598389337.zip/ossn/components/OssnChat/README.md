OssnChat
========
OssnChat chat is ajax based chat. It allow users to chat with their friends.

