<?php
	if(!ossn_isLoggedin()){
		return;
	}
?>
        <div class="sidebar ">
            <div class="sidebar-contents">

           		 <?php
          			  if (ossn_is_hook('newsfeed', "sidebar:left")) {
                			$newsfeed_left = ossn_call_hook('newsfeed', "sidebar:left", NULL, array());
               				 echo implode('', $newsfeed_left);
            		}
					echo ossn_view_form('search', array(
								'component' => 'OssnSearch',
								'class' => 'ossn-search',
								'autocomplete' => 'off',
								'method' => 'get',
								'security_tokens' => false,
								'action' => ossn_site_url("search"),
					), false);
           		 ?> 

     <div class="text-center" style="    margin-top: 10px;">
          <?php echo ossn_print('site:seleccionalenguaje').':'; ?>
     </div>

		     <ul class="estiloul" style="align-items: center;
                                  justify-content: center; display: flex;
								  flex-direction: inherit;">

					<?php if ($_SESSION['LANG'] !='es'):?>

						                               <li class="" style="margin-right: 10px; margin-left: 8px;">
						                                     <a class="back" href="<?php echo ossn_getbaseurl('lang/es'); ?>">
						                                      <img width="30px" height="15px" src='<?php echo ossn_getbaseurl('images/es.jpg'); ?>'>
						                                     </a>
						                              </li>
					<?php endif; ?>

					<?php if ($_SESSION['LANG'] !='en'):?>
						                               <li class="" style="margin-right: 10px; margin-left: 8px;">
						                                     <a class="back" href="<?php echo ossn_getbaseurl('lang/en'); ?>">
						                                      <img width="30px" height="15px" src='<?php echo ossn_getbaseurl('images/en.jpg'); ?>'>
						                                     </a>
						                              </li>
					<?php endif; ?>

					<?php if ($_SESSION['LANG'] !='fr'):?>
						                               <li class="" style="margin-right: 10px; margin-left: 8px;">
						                                     <a class="back" href="<?php echo ossn_getbaseurl('lang/fr'); ?>">
						                                      <img width="30px" height="15px" src='<?php echo ossn_getbaseurl('images/fr.jpg'); ?>'>
						                                     </a>
						                              </li>
					  <?php endif; ?>


			</ul>





            </div>
        </div>