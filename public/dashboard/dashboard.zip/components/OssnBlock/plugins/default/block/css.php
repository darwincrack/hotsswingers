.ossn-block-lists {
	background: #eee;
	border-top: 1px solid #ccc;
	padding: 10px;
}

.ossn-block-lists li {
	list-style-type: square;
    margin-left: 10px;
}

.ossn-block-lists li a {
	font-weight: bold;
}

.ossn-block-lists li span {}